-- phpMyAdmin SQL Dump
-- version 5.2.1deb1ubuntu1
-- https://www.phpmyadmin.net/
--
-- Počítač: localhost:3306
-- Vytvořeno: Čtv 25. led 2024, 13:14
-- Verze serveru: 10.11.4-MariaDB-1
-- Verze PHP: 8.2.10-2ubuntu1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `sportisimo`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `item`
--

CREATE TABLE `item` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `list_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;

--
-- Vypisuji data pro tabulku `item`
--

INSERT INTO `item` (`id`, `name`, `list_id`) VALUES
(41, '361°', 1),
(2, 'Adidas', 1),
(50, 'Altra', 1),
(43, 'Anta2', 1),
(44, 'Arc\'teryx', 1),
(12, 'ASICS', 1),
(27, 'Asics', 1),
(49, 'Bauer', 1),
(32, 'Billabong', 1),
(14, 'Brooks', 1),
(39, 'Canterbury', 1),
(7, 'Columbia', 1),
(18, 'Columbia Sportswear', 1),
(21, 'Converse', 1),
(46, 'Craghoppers', 1),
(20, 'Decathlon', 1),
(35, 'ECCO', 1),
(38, 'Everlast', 1),
(11, 'Fila', 1),
(36, 'Fjällräven', 1),
(19, 'Gymshark', 1),
(16, 'Helly Hansen', 1),
(47, 'Icebreaker', 1),
(24, 'Kappa', 1),
(37, 'Karrimor', 1),
(42, 'Li-Ning', 1),
(10, 'Lululemon', 1),
(45, 'Mammut', 1),
(23, 'Merrell', 1),
(17, 'Mizuno', 1),
(6, 'New Balance', 1),
(1, 'Nike', 1),
(15, 'Oakley', 1),
(48, 'Odlo', 1),
(9, 'Patagonia', 1),
(4, 'Puma', 1),
(30, 'Quiksilver', 1),
(5, 'Reebok', 1),
(33, 'Rip Curl', 1),
(31, 'Roxy', 1),
(40, 'Russell Athletic', 1),
(13, 'Salomon', 1),
(26, 'Sketchers', 1),
(8, 'The North Face', 1),
(34, 'Timberland', 1),
(25, 'Umbro', 1),
(3, 'Under Armour', 1),
(22, 'Vans', 1),
(29, 'Wilson', 1),
(91, 'Amethystová', 2),
(86, 'Antracitová', 2),
(70, 'Azurová', 2),
(72, 'Béžová', 2),
(56, 'Bílá', 2),
(75, 'Bronzová', 2),
(55, 'Černá', 2),
(51, 'Červená', 2),
(58, 'Fialová', 2),
(69, 'Fialová', 2),
(61, 'Hnědá', 2),
(84, 'Hořčicová', 2),
(68, 'Indigová', 2),
(65, 'Karmínová', 2),
(77, 'Khaki', 2),
(76, 'Korálová', 2),
(80, 'Levandulová', 2),
(83, 'Levandulová', 2),
(67, 'Limetková', 2),
(85, 'Lososová', 2),
(71, 'Magenta', 2),
(96, 'Mahagonová', 2),
(82, 'Mentolová', 2),
(93, 'Meruňková', 2),
(52, 'Modrá', 2),
(62, 'Námořnická', 2),
(95, 'Ocelová', 2),
(64, 'Olivová', 2),
(59, 'Oranžová', 2),
(87, 'Rubínová', 2),
(60, 'Růžová', 2),
(79, 'Růžová', 2),
(88, 'Safírová', 2),
(89, 'Smaragdová', 2),
(74, 'Stříbrná', 2),
(92, 'Švestková', 2),
(66, 'Tealová', 2),
(90, 'Topaz', 2),
(63, 'Tyrkysová', 2),
(78, 'Tyrkysová', 2),
(81, 'Vínová', 2),
(53, 'Zelená', 2),
(73, 'Zlatá', 2),
(94, 'Žaludová', 2),
(54, 'Žlutá', 2);

-- --------------------------------------------------------

--
-- Struktura tabulky `list`
--

CREATE TABLE `list` (
  `id` int(11) NOT NULL,
  `name` char(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_czech_ci;

--
-- Vypisuji data pro tabulku `list`
--

INSERT INTO `list` (`id`, `name`) VALUES
(2, 'Barvy'),
(1, 'Značky');

--
-- Indexy pro exportované tabulky
--

--
-- Indexy pro tabulku `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_item_list` (`list_id`),
  ADD KEY `list_id_name` (`list_id`,`name`);

--
-- Indexy pro tabulku `list`
--
ALTER TABLE `list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `item`
--
ALTER TABLE `item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT pro tabulku `list`
--
ALTER TABLE `list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `fk_item_lists` FOREIGN KEY (`list_id`) REFERENCES `list` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
